# Copy Parameter

## Installation
  - UnZip : `CopyParam Rev_xx`
  - Launch the installer : `CopyParam_Install.bat`

## Configuration
  - Edit and modify `%HOMEDRIVE%%HOMEPATH%\Personal\WebLinks\CopyParam.ini`

## First launch in Creo Parametric
  - Open non production drawing
  - drag and drop : `CopyParam.html` (from your personal directory %HOMEPATH%\Personal\WebLinks)
  - right clic on the html page `Add to favorites...` and `Ok`

## Usage
Now you can launch CopyParam from the creo favorites tab with an active drawing.
or Create a mapkey for launch the script
