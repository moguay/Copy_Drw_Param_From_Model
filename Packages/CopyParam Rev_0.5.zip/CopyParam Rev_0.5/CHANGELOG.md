## 0.5 (2016-02-16)

Features:

  - Add Changelog
  - Add Readme

Bugfixes:

  - Fix, rewrite tolerance value
  - Fix, suppress 'Provisonal' mention
  - Fix Script freeze, Create drawing parmeter if not not found
  
## 0.4 (2016-02-15)

Performance:

  - Cleanup old function and debug return
  
Features:

  - Css cleanup
  - Main Table centred
  - Cleanup not necessary information on interface
  - Adding management of default values in the main function
  - Correct Notification processing
  - Parms rules table added
  - Manual Revision on dwg and models added
  - New sync function
  
## 0.3 (2016-02-12)

Update Features:

  - Material and Relations regeneration
  
## 0.2 (2016-02-08)

Features:

  - Add dynamic manual parameter change
  - Separte CSS and JS
  
## 0.1 (2016-02-04)

  - Inital Commit
